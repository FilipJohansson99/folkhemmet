@echo off
setlocal
title Folkhemmet - install
echo.
echo   Installing the Folkhemmet modpack for Valheim - no account or login needed...
echo.
set "FH_DEST=%LOCALAPPDATA%\Folkhemmet"
set "FH_URL=https://raw.githubusercontent.com/FilipJohansson99/folkhemmet/main/client-pack/kit.zip"
powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "$ErrorActionPreference='Stop'; $ProgressPreference='SilentlyContinue'; try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor 3072 } catch {}; $d = $env:FH_DEST; [void][IO.Directory]::CreateDirectory($d); $z = Join-Path $env:TEMP 'fh-kit.zip'; Invoke-WebRequest -UseBasicParsing -Uri $env:FH_URL -OutFile $z; Add-Type -AssemblyName System.IO.Compression.FileSystem; $zip = [IO.Compression.ZipFile]::OpenRead($z); try { foreach ($e in $zip.Entries) { $n = ($e.FullName -replace '\\','/') -replace '^[^/]+/',''; if (-not $n -or $n.EndsWith('/')) { continue }; $t = Join-Path $d $n; if ($n -eq 'client-config.json' -and (Test-Path -LiteralPath $t)) { continue }; [void][IO.Directory]::CreateDirectory((Split-Path $t)); [IO.Compression.ZipFileExtensions]::ExtractToFile($e, $t, $true) } } finally { $zip.Dispose() }; Remove-Item -LiteralPath $z -Force"
if errorlevel 1 (
    echo.
    echo   Download failed - check your internet connection and try again.
    pause
    exit /b 1
)
call "%FH_DEST%\Play.bat"